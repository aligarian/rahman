<!DOCTYPE html>
<html><head>
  <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  
</head>
<body>




<div class="container">

    


<section>
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <?php foreach($fetchdata as $data):?>
         <form method="post">
            <div class="form-group">
              <label for="selectCountry">Select Country</label>
              
              <select class="form-control" id="selectCountry" name="selectCountry">
                
                <?php 

                  for ($i=0; $i < count($countries); $i++) { 
                    echo '<option value="'.$countries[$i]->country_name.'">'.$countries[$i]->country_name.'</option>';
                  }
                  ?>
              </select>
            </div>
            <div class="form-group">
              <label for="country">State</label>
              <input type="text" class="form-control" id="state" name="state" value="<?php echo $data->state;?>">
            </div>

            
            <input class="btn btn-default" type="submit" name="submit" id="submit" value="Update"> 
          </form>
          <?php endforeach;?>
      </div>
    </div>
   

  </section>
</div>
</body>
</html>

    <h1 class="text-center">Country Name's Entry</h1></header>
    <section>
      <div class="row">
        <div class="col-md-6 col-md-offset-3">
           <form  onsubmit="event.preventDefault(); addCountry();">
              <div class="form-group">
                <label for="country">Country</label>
                <input type="text" class="form-control" id="country" placeholder="Country name" required>
              </div>
              <button class="btn btn-default" id="submit">Submit</button> 
            </form>
        </div>
      </div>
     

    </section>
  
	
	<table class="display" id="myTable">
		<thead>
			<th>S.No</th>
			<th>Country</th>
			<th>Action</th>
		</thead>
		<tbody>
    <?php foreach($fetch as $key=>$data):?>
			<tr>
				<td><?php echo $key+1;?></td>
				<td><?php echo $data->country_name;?></td>
				
				<td><a href="<?=base_url();?>Maincontroller/update_country?id=<?php echo $data->id;?>">Update</a> |
				<a href="" onclick="deleteCountry(<?php echo $data->id; ?>);" >Delete</a></td>
			</tr>
  <?php endforeach;?>
		</tbody>
	</table>


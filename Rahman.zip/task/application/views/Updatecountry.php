<!DOCTYPE html>
<html>
<head>
	
	<title></title>
	<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
</head>
<body>
	<div class="container">
		

<header><h1 class="text-center">Update Country</h1></header>
<?php foreach($fetch as $data):?>
  <section>
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
         <form method="post">
            <div class="form-group">
              <label for="country">Country</label>
              <input type="text" class="form-control" id="country" name="country" value="<?php echo $data->country_name;?>">
            </div>
            <!-- <button class="btn btn-default" id="submit" name="submit">Submit</button> -->
            <input class="btn btn-default" type="submit" name="submit" id="submit" value="Update"> 
          </form>
      </div>
    </div>
   

  </section>
  <?php endforeach;?>


	</div>

</body>
</html>


      <h1 class="text-center">State Name's Entry</h1></header>
  <section>
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
         <form  onsubmit="event.preventDefault(); submitData();" method="post">
            <div class="form-group">
              <label for="selectCountry">Select Country</label>
              
              <select class="form-control" id="selectCountry" name="selectCountry">
                
                <?php 

                  for ($i=0; $i < count($countries); $i++) { 
                    echo '<option value="'.$countries[$i]->country_name.'">'.$countries[$i]->country_name.'</option>';
                  }
                  ?>
              </select>
            </div>
            <div class="form-group">
              <label for="country">State</label>
              <input type="text" class="form-control" id="state" name="state" placeholder="State name" required>
            </div>

            
            <input class="btn btn-default" type="submit" name="submit" id="submit" value="Submit"> 
          </form>
      </div>
    </div>
   

  </section>
  <table class="display" id="myTable">
    <thead>
      <th>Id</th>
      <th>Country</th>
      <th>State</th>
      <th>Action</th>
    </thead>
    <tbody>
    <?php foreach($states as $key=>$data):?>
      
        <tr>
          <td><?php echo $key+1;?></td>
          <td><?php echo $data->country_name;?></td>
          <td><?php echo $data->state;?></td>
          <td><a href="fetch_data_for_state?id=<?php echo $data->id; ?>">Update</a> |
          <a href="" onclick="event.preventDefault();deleteState(<?= $data->id; ?>);" >Delete</a></td>
        </tr>
      
    <?php endforeach;?>
    </tbody>
  </table>
	
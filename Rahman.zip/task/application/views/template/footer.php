</div>
</div>
  <script  src="<?php echo base_url();?>assets/jquery.min.js"></script>
  <script  src="<?php echo base_url();?>assets/bootstrap.min.js"></script>
  <script  src="<?php echo base_url();?>assets/dataTables.min.js"></script>

<script type="text/javascript" src="<?=base_url()?>assets/script.js"></script>
</body>
</html>
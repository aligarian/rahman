<?php 
/**
 * 
 */
class Mainmodel extends CI_Model
{
	
	function fetch_countries()
	{
		return $this->db->select('*')
				->from('country')
				->get()
				->result();
	}
	function fetch_country($id)
	{
		return $this->db->select('*')
				->from('country')
				->where('id',$id)
				->get()
				->result();
	}
	function Update_country($id,$country)
	{
		$data=['country_name'=>$country];
		$this->db->where('id',$id)
				->update('country',$data);		
	}
	function delete_country($id)
	{
		return $this->db->where('id',$id)
				->delete('country');
	}
	function fetch_state()
	{
		return $this->db->select('*')
				->from('state')
				->get()
				->result();
	}
	function fetch_data_for_state($id)
	{
		return $this->db->select('*')
				->from('state')
				->where('id',$id)
				->get()
				->result();
	}
	function update_state($id,$country,$state)
	{
		$data=['country_name'=>$country,
				'state'=>$state];
		$this->db->where('id',$id)
				->update('state',$data);		
	}
	function Delete_state($id)
	{
		return $this->db->where('id',$id)
				->delete('state');
	}

}
?>
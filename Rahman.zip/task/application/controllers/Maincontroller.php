<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class MainController extends CI_Controller
{
	
	function __construct()
	{
		 parent::__construct();
        $this->load->helper('url');
        $this->load->database();
        $this->load->model('Mainmodel');     
	}
	function index()
	{

		$data['fetch']=$this->Mainmodel->fetch_countries();
		$this->load->view('template/header');
		$this->load->view('Country',$data);
		$this->load->view('template/footer');
		

	}
	function insert_country()
	{
		$data=['country_name'=>$this->input->post('country')];
		$country=$this->db->insert('country',$data);
		echo json_encode($country);

	}
	function insert_state()
	{
		$data=['country_name'=>$this->input->post('selectCountry'),
				'state'=>$this->input->post('state')
				];
		$state=$this->db->insert('state',$data);
		echo json_encode($state);

	}
	function update_country()
	{
		$id=$this->input->get('id');
		$data['fetch']=$this->Mainmodel->fetch_country($id);
		$this->load->view('template/header');
		$this->load->view('updatecountry',$data);
		if ($this->input->post('submit'))
		{
			$country=$this->input->post('country');
			
			$this->Mainmodel->Update_country($id,$country);
			redirect('Maincontroller');
		}
	}
	function delete_country()
	{
		$id=$this->input->post('country');
		$Deletecountry=$this->Mainmodel->delete_country($id);
		 echo json_encode($Deletecountry);
		
	}
	function State()
	{
		$data['countries']=$this->Mainmodel->fetch_countries();
		$data['states']=$this->Mainmodel->fetch_state();
		$this->load->view('template/header');
		$this->load->view('Mystate',$data);
		$this->load->view('template/footer');
		

	}
	function fetch_data_for_state()
	{
		$id=$this->input->get('id');
		$data['fetchdata']=$this->Mainmodel->fetch_data_for_state($id);
		$data['countries']=$this->Mainmodel->fetch_countries();
		$this->load->view('template/header');
		$this->load->view('updatestate',$data);
		if ($this->input->post('submit'))
		{
			$country=$this->input->post('selectCountry');
			$state=$this->input->post('state');
			$this->Mainmodel->update_state($id,$country,$state);
			redirect('Maincontroller/State');
		}
	}
	function Delete_state()
	{
		$id=$this->input->post('state');
		
		$Deletestate=$this->Mainmodel->Delete_state($id);
		echo json_encode($Deletestate);
		
	}
}
?>
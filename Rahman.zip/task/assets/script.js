  $(document).ready( function () {
      $('#myTable').DataTable();
  } );
  function submitData(){
    var selectCountry   =$('#selectCountry').val();
          var state   =$('#state').val();
    if(state ===""){
      alert("Please enter state value.");
      return false;
    }
    var formData=new FormData();
        formData.append('selectCountry',selectCountry);
                      formData.append('state',state);
    $.ajax({
          url: base_url+"Maincontroller/insert_state",
          type: "post",
          data: formData,
          contentType:false,
          cache:false,
          processData:false,
          
          success: function(data)
          {
            console.log(data);
            alert("State added successfully.");
            location.reload();
              //alert("Country Added Successfully");
              //setTimeout(function(){location.reload();},1000);        
          }
        });
    

  };
  function deleteState(id){
    $.ajax({
        url: base_url+"Maincontroller/Delete_state",
        type: "POST",
        dataType:'json',
        data: {state:id},
        success: function(data){
          alert("State is successfully deleted.");
          location.reload();          
        }
    });
  }

  function addCountry(){
    var country   =$('#country').val();
    if(country ===""){
      alert("Please enter country value.");
      return false;
    }
    var formData=new FormData();
        formData.append('country',country);
    $.ajax({
          url: base_url+"Maincontroller/insert_country",
          type: "post",
          data: formData,
          contentType:false,
          cache:false,
          processData:false,
          
          success: function(data)
          {
            console.log(data);
            alert("Country Added Successfully");
            location.reload();
              //alert("Country Added Successfully");
              //setTimeout(function(){location.reload();},1000);        
          }
        });
    

  };
  function deleteCountry(id){
    $.ajax({
        url: base_url+"Maincontroller/delete_country",
        type: "POST",
        dataType:'json',
        data: {country:id},
        success: function(data)
        {
          console.log(data);
          alert("Country Deleted");
          location.reload();          
        }
    });
  }
